import { useMemo, useState } from "react";

const destinations = [
  {
    name: "Jaipur",
    line: "Palaces, bazaars, forts, and warm Rajasthani evenings.",
    time: "2 nights",
  },
  {
    name: "Desert Safari",
    line: "Open dunes, camel rides, jeep trails, and sunset camps.",
    time: "1 night",
  },
  {
    name: "Gujarat Dwarka",
    line: "Temple visits, sea breeze, coastal drives, and quiet ghats.",
    time: "2 nights",
  },
  {
    name: "Jammu Kashmir Gulmarg",
    line: "Snow views, gondola rides, pine valleys, and crisp mountain air.",
    time: "3 nights",
  },
];

const features = ["Custom family tours", "Hotel and cab planning", "Flexible JavaScript booking flow"];

export default function App() {
  const [selectedDestination, setSelectedDestination] = useState(destinations[0]);

  const whatsappMessage = useMemo(() => {
    return encodeURIComponent(
      `Hello Harshil Patel, I want to plan a tour for ${selectedDestination.name}. Please share details.`,
    );
  }, [selectedDestination.name]);

  return (
    <main className="min-h-screen bg-[#fff8ed] text-[#23160f]">
      <section className="relative isolate min-h-screen overflow-hidden">
        <img
          src="/images/harshil-travel-hero.jpg"
          alt="Tour SUV driving through a golden desert road at sunrise"
          className="absolute inset-0 h-full w-full scale-105 object-cover motion-safe:animate-hero-drift"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#120b07]/85 via-[#2b170c]/45 to-transparent" />
        <div className="absolute inset-x-0 top-0 z-10 flex items-center justify-between px-6 py-6 text-white md:px-12">
          <a href="#top" className="text-lg font-semibold tracking-[0.28em] uppercase">
            Harshil Patel
          </a>
          <a
            href="#plan"
            className="rounded-full border border-white/45 px-5 py-2 text-sm font-medium backdrop-blur transition hover:bg-white hover:text-[#23160f]"
          >
            Plan tour
          </a>
        </div>

        <div id="top" className="relative z-10 flex min-h-screen items-center px-6 pt-24 md:px-12 lg:px-20">
          <div className="max-w-3xl text-white">
            <p className="motion-safe:animate-fade-up text-base font-medium tracking-[0.35em] uppercase text-amber-100">
              Tours and Travels
            </p>
            <h1 className="motion-safe:animate-fade-up motion-safe:[animation-delay:120ms] mt-5 text-6xl font-black leading-[0.9] tracking-tight opacity-0 [animation-fill-mode:forwards] md:text-8xl lg:text-9xl">
              Harshil Patel
            </h1>
            <p className="motion-safe:animate-fade-up motion-safe:[animation-delay:240ms] mt-7 max-w-xl text-lg leading-8 text-amber-50/90 opacity-0 [animation-fill-mode:forwards] md:text-xl">
              Jaipur desert escapes, Gujarat Dwarka pilgrim routes, and Jammu Kashmir Gulmarg snow holidays planned with comfort, care, and local guidance.
            </p>
            <div className="motion-safe:animate-fade-up motion-safe:[animation-delay:360ms] mt-9 flex flex-col gap-3 opacity-0 [animation-fill-mode:forwards] sm:flex-row">
              <a
                href="#plan"
                className="rounded-full bg-amber-300 px-7 py-3 text-center font-semibold text-[#23160f] transition hover:-translate-y-0.5 hover:bg-white"
              >
                Build my trip
              </a>
              <a
                href={`https://wa.me/?text=${whatsappMessage}`}
                className="rounded-full border border-white/55 px-7 py-3 text-center font-semibold text-white backdrop-blur transition hover:-translate-y-0.5 hover:bg-white hover:text-[#23160f]"
              >
                WhatsApp enquiry
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 py-20 md:px-12 lg:px-20" aria-labelledby="places-heading">
        <div className="mx-auto grid max-w-6xl gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
          <div>
            <p className="text-sm font-semibold tracking-[0.3em] uppercase text-orange-700">Featured routes</p>
            <h2 id="places-heading" className="mt-4 text-4xl font-bold tracking-tight md:text-6xl">
              Four Indian journeys, one easy travel desk.
            </h2>
          </div>
          <p className="max-w-2xl text-lg leading-8 text-[#6b4a34]">
            Choose a destination and the page moves with your selection. Each route can be adjusted for family trips, friends groups, couple holidays, or pilgrimage travel.
          </p>
        </div>

        <div className="mx-auto mt-12 grid max-w-6xl gap-4 md:grid-cols-2">
          {destinations.map((destination, index) => (
            (() => {
              const isSelected = selectedDestination.name === destination.name;
              return (
            <button
              key={destination.name}
              type="button"
              onClick={() => setSelectedDestination(destination)}
              className={`group min-h-48 rounded-[2rem] border p-7 text-left transition duration-300 hover:-translate-y-1 ${
                isSelected
                  ? "border-orange-700 bg-[#23160f] text-white shadow-2xl shadow-orange-900/20"
                  : "border-orange-200 bg-transparent text-[#23160f] hover:border-orange-500"
              }`}
            >
              <span className={`text-sm font-semibold ${isSelected ? "text-amber-200" : "text-orange-600"}`}>
                0{index + 1} / {destination.time}
              </span>
              <span className="mt-6 block text-3xl font-bold">{destination.name}</span>
              <span className="mt-4 block text-base leading-7 opacity-75">{destination.line}</span>
            </button>
              );
            })()
          ))}
        </div>
      </section>

      <section id="plan" className="bg-[#23160f] px-6 py-20 text-white md:px-12 lg:px-20" aria-labelledby="plan-heading">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[1fr_0.8fr] lg:items-center">
          <div>
            <p className="text-sm font-semibold tracking-[0.3em] uppercase text-amber-200">Trip builder</p>
            <h2 id="plan-heading" className="mt-4 text-4xl font-bold tracking-tight md:text-6xl">
              Start with {selectedDestination.name}.
            </h2>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-amber-50/75">
              Send your destination, travel date, guest count, and hotel preference. Harshil Patel Tours and Travels will prepare a simple route plan with cab, stay, and sightseeing support.
            </p>
          </div>

          <form className="rounded-[2rem] border border-white/15 bg-white/8 p-6 backdrop-blur" onSubmit={(event) => event.preventDefault()}>
            <label className="block text-sm font-medium text-amber-100" htmlFor="destination">
              Selected destination
            </label>
            <select
              id="destination"
              value={selectedDestination.name}
              onChange={(event) => {
                const nextDestination = destinations.find((item) => item.name === event.target.value);
                if (nextDestination) setSelectedDestination(nextDestination);
              }}
              className="mt-2 w-full rounded-2xl border border-white/15 bg-[#120b07] px-4 py-3 text-white outline-none transition focus:border-amber-300"
            >
              {destinations.map((destination) => (
                <option key={destination.name}>{destination.name}</option>
              ))}
            </select>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <input
                aria-label="Travel date"
                type="date"
                className="rounded-2xl border border-white/15 bg-[#120b07] px-4 py-3 text-white outline-none transition focus:border-amber-300"
              />
              <input
                aria-label="Number of travelers"
                type="number"
                min="1"
                placeholder="Travelers"
                className="rounded-2xl border border-white/15 bg-[#120b07] px-4 py-3 text-white outline-none transition placeholder:text-white/50 focus:border-amber-300"
              />
            </div>

            <button className="mt-6 w-full rounded-full bg-amber-300 px-7 py-3 font-semibold text-[#23160f] transition hover:-translate-y-0.5 hover:bg-white">
              Request plan
            </button>
          </form>
        </div>
      </section>

      <section className="px-6 py-16 md:px-12 lg:px-20" aria-label="Service highlights">
        <div className="mx-auto flex max-w-6xl flex-col gap-5 border-t border-orange-200 pt-10 md:flex-row md:items-center md:justify-between">
          <h2 className="max-w-xl text-3xl font-bold tracking-tight">Travel help that stays personal from first call to return home.</h2>
          <div className="space-y-3 text-[#6b4a34]">
            {features.map((feature) => (
              <p key={feature} className="motion-safe:animate-soft-float text-lg font-medium">
                {feature}
              </p>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}